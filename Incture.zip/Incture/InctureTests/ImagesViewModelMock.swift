//
//  ImagesViewModelMock.swift
//  InctureTests
//
//  Created by Rahul Patil on 13/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//

import Foundation
@testable import Incture
import XCTest

final class ImagesViewModelMock: ImagesViewModelInput {
    private(set) var onViewDidLoadCallCount: Int = 0
    private(set) var onViewWillAppearCallCount: Int = 0
    private(set) var onViewWillDisappearCallCount: Int = 0
    
    private(set) var searchNewImagesCallCount: Int = 0
    
    private(set) var numberOfItemsCountCallCount: Int = 0
    private(set) var presentableRPImageCallCount: Int = 0
    
    private(set) var collectionViewCellForItemAtCallCount: Int = 0
    private(set) var collectionViewWillBeginDraggingCallCount: Int = 0
    private(set) var collectionViewDidEndDraggingCallCount: Int = 0
    
    private(set) var scrollViewReachedAtMaxCallCount: Int = 0
    
    private(set) var loadImagesOnScreenVisibleCellsCallCount: Int = 0
    
    func onViewDidLoad() {
        onViewDidLoadCallCount += 1
    }
    func onViewWillAppear() {
       onViewWillAppearCallCount += 1
    }
    func onViewWillDisappear() {
       onViewWillDisappearCallCount += 1
    }
    
    func searchNewImages(for query: String) {
       searchNewImagesCallCount += 1
    }
    
    func numberOfItemsCount() -> Int {
       numberOfItemsCountCallCount += 1
        return numberOfItemsCountCallCount
    }
    func presentableRPImage(at index: Int) -> RPImage? {
        presentableRPImageCallCount += 1
        return RPImage("123", imageUrl: URL(string: "http://tineye.com/images/widgets/mona.jpg")!)
    }
    
    func collectionViewCellForItemAt(_ indexPath: IndexPath) {
       collectionViewCellForItemAtCallCount += 1
    }
    func collectionViewWillBeginDragging() {
       collectionViewWillBeginDraggingCallCount += 1
    }
    func collectionViewDidEndDragging() {
       collectionViewDidEndDraggingCallCount += 1
    }
    
    func scrollViewReachedAtMax() {
       scrollViewReachedAtMaxCallCount += 1
    }
    
    func loadImagesOnScreenVisibleCells(_ indexPaths: [IndexPath]) {
       loadImagesOnScreenVisibleCellsCallCount += 1
    }
}

