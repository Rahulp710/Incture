//
//  PinterestLayoutMock.swift
//  InctureTests
//
//  Created by Rahul Patil on 13/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//

import Foundation
import UIKit
@testable import Incture

final class PinterestLayoutMock: UICollectionViewLayout {
    
    private(set) var collectionViewContentSizeCallCount: Int = 0
    private(set) var prepareCallCount: Int = 0
    private(set) var layoutAttributesForElementsCallCount: Int = 0
    private(set) var layoutAttributesForItemCallCount: Int = 0
    private(set) var invalidateLayoutCallCount: Int = 0
    
    override var collectionViewContentSize: CGSize {
        collectionViewContentSizeCallCount += 1
        return .zero
    }
    
    override func prepare() {
        super.prepare()
        prepareCallCount += 1
    }
    
    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        layoutAttributesForElementsCallCount += 1
        return nil
    }
    
    override func layoutAttributesForItem(at indexPath: IndexPath) -> UICollectionViewLayoutAttributes? {
        layoutAttributesForItemCallCount += 1
        return nil
    }
    
    override func invalidateLayout() {
        invalidateLayoutCallCount += 1
    }
}
