//
//  ImagesRequestMock.swift
//  InctureTests
//
//  Created by Rahul Patil on 13/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//

import Foundation
import UIKit
@testable import Incture

final class ImagesRequestMock: ImagesNetworkProtocol {
    
    private(set) var fetchImagesCallCount: Int = 0
    var apiSuccessful: Bool = false
    private(set) var imagesCallCount: Int = 0
    private(set) var responseRawData: [String:Any] = [
        "total":48978,
        "total_pages":4898,
        "results":[
            ["id":"yWwob8kwOCk",
             "width":2301,
             "height":1536,
             "urls":["regular":"https://images.unsplash.com/photo-1497366754035-f200968a6e72?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjc2MTU4fQ"],
            ],
            ["id":"BlIhVfXbi9s",
             "width":6016,
             "height":4016,
             "urls":["regular":"https://images.unsplash.com/photo-1533090161767-e6ffed986c88?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjc2MTU4fQ"],
            ],
            ["id":"nC6CyrVBtkU",
             "width":2878,
             "height":3381,
             "urls":["regular":"https://images.unsplash.com/photo-1570126618953-d437176e8c79?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjc2MTU4fQ"],
            ],
            ["id":"wawEfYdpkag",
             "width":5355,
             "height":4016,
             "urls":["regular":"https://images.unsplash.com/photo-1556761175-4b46a572b786?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjc2MTU4fQ"],
            ],
            ["id":"iusJ25iYu1c",
             "width":4240,
             "height":2832,
             "urls":["regular":"https://images.unsplash.com/photo-1520607162513-77705c0f0d4a?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjc2MTU4fQ"],
            ],
            ["id":"BlIhVfXbi92",
             "width":6016,
             "height":4016,
             "urls":["regular":"https://images.unsplash.com/photo-1533090161767-e6ffed986c88?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjc2MTU4fQ"],
            ],
            ["id":"BlIhVfXbi12s",
             "width":6016,
             "height":4016,
             "urls":["regular":"https://images.unsplash.com/photo-1533090161767-e6ffed986c88?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjc2MTU4fQ"],
            ],
              ["id":"BlIhVfXbi1469s",
               "width":6016,
               "height":4016,
               "urls":["regular":"https://images.unsplash.com/photo-1533090161767-e6ffed986c88?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjc2MTU4fQ"],
              ]
        ]
    ]


    func convertDictionaryToJsonData(_ dict: [String:Any]) -> Data? {
        guard let jsonData = try? JSONSerialization.data(withJSONObject: dict, options: []) else { return nil }
        return jsonData
    }

    func fetchImages(for query: String, with page: Int, completion: @escaping(Result<[String: Any], Error>) -> Void) {
        fetchImagesCallCount += 1
        if apiSuccessful == true {
            if let jsonData = convertDictionaryToJsonData(responseRawData) {
                do {
                    if let result = try JSONSerialization.jsonObject(with: jsonData, options: JSONSerialization.ReadingOptions.allowFragments) as? [String: Any] {
                        if let images = result["results"] as? [[String: Any]] {
                            imagesCallCount = images.count
                        }
                        completion(.success(result))
                    }
                } catch let error {
                    completion(.failure(error))
                }
            } else {
                completion(.success([String: Any]()))
            }
        } else {
           // Got error need to handle
        }

    }
}
