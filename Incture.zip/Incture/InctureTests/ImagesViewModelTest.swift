//
//  ImagesViewModelTest.swift
//  InctureTests
//
//  Created by Rahul Patil on 13/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//

import Foundation
import XCTest
@testable import Incture

final class ImagesViewModelTest: XCTestCase {
    private var network: ImagesRequestMock!
    private var pendingOperations: PendingOperationsMock!
    private var delegate: ImagesViewModelOutputMock!
    private var viewModel: ImagesViewModel!

    override func setUp() {
        super.setUp()
        network = ImagesRequestMock()
        pendingOperations = PendingOperationsMock()
        viewModel = ImagesViewModel(network, and: pendingOperations)
        delegate = ImagesViewModelOutputMock()
        viewModel.delegate = delegate
    }
    
    override func tearDown() {
        super.tearDown()
        network = nil
        delegate = nil
        viewModel = nil
        pendingOperations = nil
    }
    
    func test_Fetch_Images_failed() {
        network.apiSuccessful = false
        viewModel.onViewDidLoad()
        XCTAssertEqual(network.fetchImagesCallCount, 1)
        XCTAssertEqual(network.imagesCallCount, 0)
        XCTAssertEqual(viewModel.numberOfItemsCount(), 0)
    }
    
    func test_Fetch_Images_Success() {
        network.apiSuccessful = true
        viewModel.onViewDidLoad()
        XCTAssertEqual(network.fetchImagesCallCount, 1)
        XCTAssertEqual(network.imagesCallCount, 8)
        XCTAssertEqual(viewModel.numberOfItemsCount(), 8)
    }
}
