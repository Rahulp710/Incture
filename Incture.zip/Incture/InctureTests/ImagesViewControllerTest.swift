//
//  ImagesViewControllerTest.swift
//  InctureTests
//
//  Created by Rahul Patil on 13/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//

import Foundation
import UIKit
import XCTest
@testable import Incture

final class ImagesViewControllerTest: XCTestCase {
    
    private var layout: UICollectionViewLayout!
    private var viewModel: ImagesViewModelMock!
    private var imagesViewController: ImagesViewController!

    override func setUp() {
        super.setUp()
        layout = PinterestLayoutMock()
        viewModel = ImagesViewModelMock()
        imagesViewController = ImagesViewController(viewModel, layout: layout)
    }
    
    override func tearDown() {
        super.tearDown()
        layout = nil
        viewModel = nil
        imagesViewController = nil
    }
    
    func test_ImagesViewController_OnViewDidLoad() {
        viewModel.onViewDidLoad()
        XCTAssertNotNil(viewModel.onViewDidLoadCallCount)
        XCTAssertEqual(viewModel.onViewDidLoadCallCount, 1)
    }
    
    func test_ImagesViewController_OnViewWillAppear() {
        viewModel.onViewWillAppear()
        XCTAssertNotNil(viewModel.onViewWillAppearCallCount)
        XCTAssertEqual(viewModel.onViewWillAppearCallCount, 1)
    }

    func test_ImagesViewController_OnViewWillDisappear() {
        viewModel.onViewWillDisappear()
        XCTAssertNotNil(viewModel.onViewWillDisappearCallCount)
        XCTAssertEqual(viewModel.onViewWillDisappearCallCount, 1)
    }
    
    func test_ImagesViewController_NumberOfItemsInSection() {
        let count = viewModel.numberOfItemsCount()
        XCTAssertNotNil(viewModel.numberOfItemsCountCallCount)
        XCTAssertEqual(viewModel.numberOfItemsCountCallCount, 1)
        XCTAssertEqual(viewModel.numberOfItemsCountCallCount, count)
    }
    
    func test_ImagesViewController_CollectionViewCellForItemAtIndexPath() {
        let indexPath = IndexPath(item: 0, section: 0)
        let image = viewModel.presentableRPImage(at: indexPath.item)
        XCTAssertNotNil(image)
        XCTAssertEqual(viewModel.presentableRPImageCallCount, 1)
    }
    
    
    func test_ImagesViewController_CollectionViewCellForItemAt() {
        let indexPath = IndexPath(item: 0, section: 0)
        viewModel.collectionViewCellForItemAt(indexPath)
        XCTAssertNotNil(viewModel.collectionViewCellForItemAtCallCount)
        XCTAssertEqual(viewModel.collectionViewCellForItemAtCallCount, 1)
    }
}
