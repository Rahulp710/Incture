//
//  PendingOperationsMock.swift
//  InctureTests
//
//  Created by Rahul Patil on 13/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//

import Foundation
@testable import Incture

final class PendingOperationsMock: PendingOperationsProtocol {

    private(set) var downloadInProgressCallCount: Int = 0
    private(set) var downloadQueueCallCount: Int = 0
    
    var downloadInProgress: [IndexPath : Operation] = [:] {
        didSet {
            downloadInProgressCallCount += 1
        }
    }
    var downloadQueue: OperationQueue {
        downloadQueueCallCount += 1
        return OperationQueue()
    }
}
