//
//  ImagesViewModelOutputMock.swift
//  InctureTests
//
//  Created by Rahul Patil on 13/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//

import Foundation
@testable import Incture

final class ImagesViewModelOutputMock: ImagesViewModelOutput {
    private(set) var onFetchCompletedCallCount: Int = 0
    private(set) var onFetchFailedCallCount: Int = 0
    private(set) var clearAllImagesCallCount: Int = 0
    private(set) var collectionViewReloadItemsAtCallCount: Int = 0

    func onFetchCompleted(with images: [RPImage]) {
        onFetchCompletedCallCount += 1
    }
    func onFetchFailed(with message: String) {
        onFetchFailedCallCount += 1
    }
    
    func clearAllImages() {
        clearAllImagesCallCount += 1
    }

    func collectionViewReloadItemsAt(_ indexPaths: [IndexPath]) {
        collectionViewReloadItemsAtCallCount += 1
    }
}
