//
//  RPImage.swift
//  Incture
//
//  Created by Rahul Patil on 11/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//

import Foundation
import UIKit

enum ImageState {
    case new, downloaded, failed
}

protocol RPImageProtocol {
    var id: String { get }
    var url: URL { get }
    var scale: CGFloat { get }
    var state: ImageState { get set }
    var imageData: Data? { get set }
    init(_ newId: String, imageUrl: URL, newScale: CGFloat, imageState: ImageState, data: Data?)
}

class RPImage: RPImageProtocol, Hashable {
    
    let id: String
    let url: URL
    let scale: CGFloat
    var state: ImageState
    var imageData: Data?
    
    required init(_ newId: String, imageUrl: URL, newScale: CGFloat = 1.0, imageState: ImageState = .new, data: Data? = nil) {
        id = newId
        url = imageUrl
        scale = newScale
        state = imageState
        imageData = data
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
        hasher.combine(url)
        hasher.combine(scale)
        hasher.combine(state)
        hasher.combine(imageData)
    }
    
    static func == (lhs: RPImage, rhs: RPImage) -> Bool {
        return lhs.id == rhs.id
    }
}
