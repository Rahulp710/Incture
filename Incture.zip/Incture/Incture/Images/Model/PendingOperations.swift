//
//  PendingOperations.swift
//  Incture
//
//  Created by Rahul Patil on 11/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//

import Foundation
import UIKit

protocol PendingOperationsProtocol  {
    var downloadInProgress: [IndexPath: Operation] { get set }
    var downloadQueue: OperationQueue { get }
}

class PendingOperations: PendingOperationsProtocol {
    lazy var downloadInProgress: [IndexPath: Operation] = [:]
    lazy var downloadQueue: OperationQueue = {
        var queue = OperationQueue()
        queue.name = "Download Queue"
        queue.maxConcurrentOperationCount = 1
        return queue
    }()
}
