//
//  ImagesViewModel.swift
//  Incture
//
//  Created by Rahul Patil on 11/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//

import Foundation
import UIKit

protocol ImagesViewModelInput {
    
    func onViewDidLoad()
    func onViewWillAppear()
    func onViewWillDisappear()
    
    func searchNewImages(for query: String)
    
    func numberOfItemsCount() -> Int
    func presentableRPImage(at index: Int) -> RPImage?
    
    func collectionViewCellForItemAt(_ indexPath: IndexPath)
    func collectionViewWillBeginDragging()
    func collectionViewDidEndDragging()
    
    func scrollViewReachedAtMax()
    
    func loadImagesOnScreenVisibleCells(_ indexPaths: [IndexPath])
}

protocol ImagesViewModelOutput: class {
    
    func onFetchCompleted(with images: [RPImage])
    func onFetchFailed(with message: String)
    
    func clearAllImages()

    func collectionViewReloadItemsAt(_ indexPaths: [IndexPath])
}

class ImagesViewModel: ImagesViewModelInput {
    
    weak var delegate: ImagesViewModelOutput?
    
    fileprivate var images = [RPImage]()
    
    private var query = ""
    private var totalImages = 0
    private var currentPage = 1
    
    private var reachedMaxLimit = false
    private var isFetchInProgress = false

    
    private let imageAPI: ImagesNetworkProtocol!
    private var pendingOperations: PendingOperationsProtocol!
        
    init(_ imageAPI: ImagesNetworkProtocol, and pendingOperations: PendingOperationsProtocol) {
        self.imageAPI = imageAPI
        self.pendingOperations = pendingOperations
    }
    
    // MARK: - Inputs -
    func onViewDidLoad() {
        getImages()
    }
    
    func onViewWillAppear() {
        resumeAllOperations()
    }
    
    func onViewWillDisappear() {
        suspendAllOpertions()
    }
    
    func searchNewImages(for newQuery: String) {
        query = newQuery
        currentPage = 1
        reachedMaxLimit = false
        delegate?.clearAllImages()
        getImages()
    }

    func numberOfItemsCount() -> Int {
        return images.count
    }
        
    func presentableRPImage(at index: Int) -> RPImage? {
        guard index < images.count else { return nil }
        return images[index]
    }
    
    func collectionViewCellForItemAt(_ indexPath: IndexPath) {
        if let image = presentableRPImage(at: indexPath.item) {
            startDownload(for: image, at: indexPath)
        }
    }
        
    func collectionViewWillBeginDragging() {
        suspendAllOpertions()
    }
    
    func collectionViewDidEndDragging() {
        resumeAllOperations()
    }
    
    func scrollViewReachedAtMax() {
        getImages()
    }

    
    // Load images after scrolling stops or viewWillAppear called on visible cells
    // If images not downloaded yet then start them to download
    // Other all pending operation who are cancelled remove from pending operation dicationary
    func loadImagesOnScreenVisibleCells(_ indexPaths: [IndexPath]) {
        if indexPaths.count > 0 {
            let allPendingOperations = Set(pendingOperations.downloadInProgress.keys)
            let visibleIndexPath = Set(indexPaths)
            
            var toBecancelled = allPendingOperations
            toBecancelled.subtract(visibleIndexPath)
            
            var toBeStarted = visibleIndexPath
            toBeStarted.subtract(allPendingOperations)
            
            for indexPath in toBecancelled {
                if let pendingDownload = pendingOperations.downloadInProgress[indexPath] {
                    pendingDownload.cancel()
                }
                pendingOperations.downloadInProgress.removeValue(forKey: indexPath)
            }
            for indexPath in toBeStarted {
                if let recordToProcess = presentableRPImage(at: indexPath.item),
                    recordToProcess.state == .new {
                    startDownload(for: recordToProcess, at: indexPath)
                }
            }
        }
    }
}

extension ImagesViewModel {
    
    /// Get Images from server
    private func getImages() {
        if reachedMaxLimit {
            return
        }
        guard !isFetchInProgress else {
            return
        }
        isFetchInProgress = true
        imageAPI.fetchImages(for: query, with: currentPage) { [unowned self] (result) in
            self.isFetchInProgress = false
            if self.currentPage == 1 {
                self.images = [RPImage]()
            }
            switch result {
            case .success(let response):
                self.parseResponse(response)
                
            case .failure(let error):
                print("Got an error and error is \(error.localizedDescription)")
                self.delegate?.onFetchFailed(with: error.localizedDescription)
            }
        }
    }
    
    /// Parse Response
    /// - Parameter response: response as dictionary
    private func parseResponse(_ response: [String: Any]) {
        if let total = response["total"] as? Int {
            totalImages = total
        }
        if let totalPages = response["total_pages"] as? Int, totalPages > currentPage {
            currentPage += 1
        }
        if let result = response["results"] as? [[String: Any]] {
            let newImageDicts = result.map({$0})
            for image in newImageDicts {
                if let id = image["id"] as? String,
                    let urls = image["urls"] as? [String: Any],
                let imageUrl = urls["regular"] as? String,
                    let url = URL(string: imageUrl) {
                    var scale: CGFloat = 1.0
                    if let width = image["width"] as? Int,
                        let height = image["height"] as? Int {
                        scale = CGFloat(width)/CGFloat(height)
                    }
                    images.append(RPImage(id, imageUrl: url, newScale: scale))
                }
            }
            reachedMaxLimit = images.count < totalImages ? false : true
            delegate?.onFetchCompleted(with: images)
        }
    }

    
    // Add image downloader operation in pending operation queue
    // Once image download complete remove it from operation  dictionary
    // Reload particular collectionview cell
    private func startDownload(for image: RPImage, at indexPath: IndexPath) {
        guard pendingOperations.downloadInProgress[indexPath] == nil else { return }
        let downloader = ImageDownloader(image)
        downloader.completionBlock = {
            if downloader.isCancelled {
                return
            }
            self.pendingOperations.downloadInProgress.removeValue(forKey: indexPath)
            self.delegate?.collectionViewReloadItemsAt([indexPath])
        }
        pendingOperations.downloadInProgress[indexPath] = downloader
        pendingOperations.downloadQueue.addOperation(downloader)
    }
    
    // While scrolling or viewWillDisapper supspend all image download operations
    private func suspendAllOpertions() {
        pendingOperations.downloadQueue.isSuspended = true
    }
    
    // Whiwhen scrolling stops or ViewWillAppear called all supspended operations make it resume and then can start download images
    private func resumeAllOperations() {
        pendingOperations.downloadQueue.isSuspended = false
    }
}
