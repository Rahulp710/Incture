//
//  ImagesRequest.swift
//  Incture
//
//  Created by Rahul Patil on 11/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//

import Foundation

protocol ImagesNetworkProtocol {
    
    func fetchImages(for query: String, with page: Int, completion: @escaping(Result<[String: Any], Error>) -> Void)
}

class ImagesRequest: ImagesNetworkProtocol {
    
    /// Fetch Restaurants details
    /// - Parameter completion: Result will contain array of Restauarnts or error
    func fetchImages(for query: String, with page: Int, completion: @escaping(Result<[String: Any], Error>) -> Void) {
        guard query.count > 0 else {
            completion(.success([String: Any]()))
            return
        }
        let strUrl = "https://api.unsplash.com/search/photos?page=\(page)&query=\(query)&client_id=d8a272c480b258b875d82f4062d6c52e4ae7f4b4656add778d71e9b638b2f8be"

        guard let url = URL(string: strUrl) else { return }
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let error = error {
                completion(.failure(error))
            }
            guard let jsonData = data else {
                completion(.success([String: Any]()))
                return
            }
            do {
                if let result = try JSONSerialization.jsonObject(with: jsonData, options: JSONSerialization.ReadingOptions.allowFragments) as? [String: Any] {
                    completion(.success(result))
                }
            } catch let error {
                completion(.failure(error))
            }
        }
        task.resume()
    }
}
