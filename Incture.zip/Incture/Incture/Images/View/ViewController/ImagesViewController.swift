//
//  ImagesViewController.swift
//  Incture
//
//  Created by Rahul Patil on 11/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//

import UIKit

class ImagesViewController: UIViewController {
    
    private let viewModel:ImagesViewModelInput!
    private var dataSource: UICollectionViewDiffableDataSource<Section, RPImage>!
    private var layout: UICollectionViewLayout!
    let searchController = UISearchController(searchResultsController: nil)
    let scopeButtonTitles = ["Tiger", "Horse", "Elephant", "Lion", "Deer"]
    
    init(_ viewModel: ImagesViewModelInput, layout: UICollectionViewLayout) {
        self.viewModel = viewModel
        self.layout = layout
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var imageSize: CGSize?
    var scale: CGFloat?
    var collectionViewScrolling = false
    var viewWillDisappear = false
    
    // Avoid thread explosion when doing asynchronous work
    private let serialQueue = DispatchQueue(label: "Decode Queue")
    private let cache = ImageCache.shared
    
    // We keep track of the pending work item as a property
    private var pendingRequestWorkItem: DispatchWorkItem?

    private var collectionView: UICollectionView!
//    private var searchBar: UISearchBar!
    private var indicatorView: UIActivityIndicatorView!
}

extension ImagesViewController {
    
    fileprivate enum Section {
        case main
    }
}

extension ImagesViewController {
    
    override func loadView() {
         super.loadView()
        setUpNavigationTitle()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        viewModel.onViewDidLoad()
        configureDateSource()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if viewWillDisappear {
            viewWillDisappear = false
            viewModel.onViewWillAppear()
            viewModel.loadImagesOnScreenVisibleCells(collectionView.indexPathsForVisibleItems)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        viewWillDisappear = true
        viewModel.onViewWillDisappear()
    }
    
    override func didReceiveMemoryWarning() {
        cache.removeAllImages()
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        guard previousTraitCollection != nil else { return }
        layout.invalidateLayout()
    }
    
    private func setUpNavigationTitle() {
        navigationItem.title = "Images"
        setUpSearchBar()
        setUpCollectionView()
        setUpActivityIndictorView()
    }
    
    private func setUpSearchBar() {
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search Animal Images"
        navigationItem.searchController = searchController
        definesPresentationContext = true
        searchController.searchBar.scopeButtonTitles = scopeButtonTitles
        searchController.searchBar.delegate = self
    }
    
    private func registerCell(_ cellName: String) {
        let nibName = UINib(nibName: cellName, bundle: nil)
        collectionView.register(nibName, forCellWithReuseIdentifier: cellName)
    }
    
    private func setUpCollectionView() {
        let collectionView = UICollectionView(frame: self.view.frame, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.backgroundColor = .systemBackground
        collectionView.accessibilityIdentifier = "ImagesViewController.collectionView"
        collectionView.keyboardDismissMode = .onDrag
        self.collectionView = collectionView
        view.addSubview(collectionView)
        
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
        ])
        
        registerCell(String(describing: ImageCell.self))
        collectionView.isHidden = true
        collectionView.delegate = self
    }
    
    private func setUpActivityIndictorView() {
        let indicatorView = UIActivityIndicatorView()
        indicatorView.accessibilityIdentifier = "ImagesViewController.indicatorView"
        indicatorView.startAnimating()
        indicatorView.hidesWhenStopped = true
        indicatorView.translatesAutoresizingMaskIntoConstraints = false
        self.indicatorView = indicatorView
        view.addSubview(indicatorView)
        NSLayoutConstraint.activate([
            indicatorView.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            collectionView.centerYAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerYAnchor),
        ])
    }
    
    private func configureDateSource() {
        dataSource = UICollectionViewDiffableDataSource<Section, RPImage>(collectionView: collectionView, cellProvider: { (collectionView, indexPath, image) -> UICollectionViewCell? in
            guard let image = self.viewModel.presentableRPImage(at: indexPath.item),
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: String(describing: ImageCell.self), for: indexPath) as? ImageCell else {
                    assertionFailure("Must initialize the cell")
                    return UICollectionViewCell()
            }
            cell.imageView.image = nil
            cell.layoutIfNeeded()
            
            cell.backView.addShadow()
            cell.imageView.clipCorners()
            cell.activityIndicator.transform = UIDevice.current.userInterfaceIdiom == .pad ? CGAffineTransform(scaleX: 2.5, y: 2.5) : CGAffineTransform.identity
            
            self.imageSize = cell.imageView.bounds.size
            self.addImage(to: cell.imageView, with: cell.activityIndicator, and: image, at: indexPath)
            
            cell.layoutIfNeeded()
            return cell
        })
    }
    
    private func createSnapShot(from images: [RPImage]) {
        DispatchQueue.main.async {
            var snapshot = NSDiffableDataSourceSnapshot<Section, RPImage>()
            snapshot.appendSections([.main])
            snapshot.appendItems(images)
            self.dataSource.apply(snapshot, animatingDifferences: true, completion: nil)
        }
    }
    
    private func addImage(to imageView: UIImageView,
                          with activityIndicator: UIActivityIndicatorView,
                          and image: RPImage?,
                          at indexPath: IndexPath) {
        if let image = image {
            switch image.state {
            case .new:
                activityIndicator.startAnimating()
                // If collectionView is not scrolling then start download image
                if !collectionView.isDragging && !collectionView.isDecelerating {
                    viewModel.collectionViewCellForItemAt(indexPath)
                }
            case .downloaded:
                activityIndicator.stopAnimating()
                // Checking for cached image
                if let cachedImage = self.cache.image(for: image.url) {
                    imageView.image = cachedImage
                } else if let data = image.imageData {
                    let imageSize = imageView.bounds.size
                    let scale = collectionView.traitCollection.displayScale
                    
                    // Creating downsample image for reducing memory
                    // This reduced image size near by 50%
                    let downsampledImage = UIImage.downsample(imageAt: data, to: imageSize, scale: scale)
                    UIView.transition(with: imageView,
                                      duration: 0.5,
                                      options: .transitionCrossDissolve,
                                      animations: {
                        imageView.image = downsampledImage
                    }, completion: nil)

                    // Storing downsampled image in cache with respect to url
                    self.cache.insertImage(downsampledImage, for: image.url)
                }
                
            case .failed:
                activityIndicator.stopAnimating()
                imageView.image = nil
            }
        }
    }
    
    private func prefetchImage(to image: RPImage?,
                               with imageSize: CGSize?,
                               at indexPath: IndexPath) {
        if let image = image {
            switch image.state {
            case .new:
                serialQueue.async {
                    self.viewModel.collectionViewCellForItemAt(indexPath)
                }
                
            case .downloaded:
                if let _ = cache.image(for: image.url) {
                    break
                } else if let data = image.imageData {
                    serialQueue.async {
                        // Creating downsample image for reducing memory
                        guard let imageSize = imageSize else { return }
                        let scale = self.collectionView.traitCollection.displayScale
                        let downsampledImage = UIImage.downsample(imageAt: data, to: imageSize, scale: scale)
                        
                        // Storing downsampled image in cache with respect to url
                        self.cache.insertImage(downsampledImage, for: image.url)
                    }
                }
                
            case .failed: break
            }
        }
    }
    
    private func visibleIndexPathsToReload(intersecting indexPaths: [IndexPath]) -> [IndexPath] {
        let indexPathsForVisibleRows = collectionView.indexPathsForVisibleItems
        let indexPathsIntersection = Set(indexPathsForVisibleRows).intersection(indexPaths)
        return Array(indexPathsIntersection)
    }
}

extension ImagesViewController: UISearchResultsUpdating {
    
    func updateSearchResults(for searchController: UISearchController) {
        let searchBar = searchController.searchBar
        if let scopeButtonTitles = searchBar.scopeButtonTitles {
            let query = scopeButtonTitles[searchBar.selectedScopeButtonIndex]
            
            // Cancel the currently pending item
            pendingRequestWorkItem?.cancel()
            
            // Wrap our request in a work item
            let requestWorkItem = DispatchWorkItem { [weak self] in
                self?.viewModel.searchNewImages(for: query.lowercased() + (searchBar.text ?? ""))
            }
            
            // Save the new work item and execute it after 250 msil
            pendingRequestWorkItem = requestWorkItem
            DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(500),
                                          execute: requestWorkItem)
            
        }
    }
}

extension ImagesViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        if let scopeButtonTitles = searchBar.scopeButtonTitles {
            let query = scopeButtonTitles[selectedScope]
            
            // Cancel the currently pending item
            pendingRequestWorkItem?.cancel()
            
            // Wrap our request in a work item
            let requestWorkItem = DispatchWorkItem { [weak self] in
                self?.viewModel.searchNewImages(for: query.lowercased() + (searchBar.text ?? ""))
            }
            
            // Save the new work item and execute it after 250 ms
            pendingRequestWorkItem = requestWorkItem
            DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(500),
                                          execute: requestWorkItem)
            
        }
    }

//    func searchBar(_ searchBar: UISearchBar, textDidChange textSearched: String) {
//        // Cancel the currently pending item
//        pendingRequestWorkItem?.cancel()
//
//        // Wrap our request in a work item
//        let requestWorkItem = DispatchWorkItem { [weak self] in
//            self?.viewModel.searchNewImages(for: textSearched.lowercased())
//        }
//
//        // Save the new work item and execute it after 250 ms
//        pendingRequestWorkItem = requestWorkItem
//        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(500),
//                                      execute: requestWorkItem)
//
//    }
}

extension ImagesViewController: ImagesViewModelOutput {
    
    func onFetchCompleted(with images: [RPImage]) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            if self.collectionView.isHidden {
                self.indicatorView.stopAnimating()
                self.collectionView.isHidden = false
            }
            self.createSnapShot(from: images)
        }
    }
    
    func onFetchFailed(with message: String) {
        DispatchQueue.main.async { [weak self] in
            self?.indicatorView.stopAnimating()
            let alertVC = UIAlertController(title: "Message", message: message, preferredStyle: .alert)
            alertVC.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self?.present(alertVC, animated: true, completion: nil)
        }
    }
    
    func clearAllImages() {
        DispatchQueue.main.async {
            var currentSnapshot = self.dataSource.snapshot()
            currentSnapshot.deleteAllItems()
            self.dataSource.apply(currentSnapshot, animatingDifferences: false)
            self.collectionView.contentSize = .zero
            self.layout.invalidateLayout()
            self.collectionView.isHidden = true
            self.indicatorView.startAnimating()
        }
    }
    
    func collectionViewReloadItemsAt(_ indexPaths: [IndexPath]) {
        DispatchQueue.main.async {
            let indexPathToReload = self.visibleIndexPathsToReload(intersecting: indexPaths)
            for indexPath in indexPathToReload {
                if let image = self.viewModel.presentableRPImage(at: indexPath.row) {
                    var currentSnapshot = self.dataSource.snapshot()
                    currentSnapshot.reloadItems([image])
                    self.dataSource.apply(currentSnapshot, animatingDifferences: false)
                }
            }
        }
    }
}

extension ImagesViewController: PinterestLayoutDelegate {
    
    func numberOfItems() -> Int {
        return viewModel.numberOfItemsCount()
    }
    
    func scaleForImage(at indexPath: IndexPath) -> CGFloat {
        guard let image = viewModel.presentableRPImage(at: indexPath.item) else { return 1.0 }
        return image.scale
    }
}

extension ImagesViewController: UICollectionViewDataSourcePrefetching {
    
    func collectionView(_ collectionView: UICollectionView, prefetchItemsAt indexPaths: [IndexPath]) {
        // Check for collectionView is scrolling or not. If not scrollng then prefect next Item for indexpaths
        if !self.collectionViewScrolling {
            for indexPath in indexPaths {
                guard let image = self.viewModel.presentableRPImage(at: indexPath.item) else { return }
                self.prefetchImage(to: image, with: imageSize, at: indexPath)
            }
        }
    }
}

extension ImagesViewController: UICollectionViewDelegate, UIScrollViewDelegate {
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        collectionViewScrolling = true
        viewModel.collectionViewWillBeginDragging()
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if !decelerate {
            collectionViewScrolling = false
            viewModel.collectionViewDidEndDragging()
            viewModel.loadImagesOnScreenVisibleCells(collectionView.indexPathsForVisibleItems)
        }
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        collectionViewScrolling = false
        viewModel.collectionViewDidEndDragging()
        viewModel.loadImagesOnScreenVisibleCells(collectionView.indexPathsForVisibleItems)
        
        let currentOffset: CGFloat = scrollView.contentOffset.y
        let contentHeight: CGFloat = scrollView.contentSize.height
        let scrollHeight: CGFloat = scrollView.frame.size.height
        
        if currentOffset + scrollHeight  >= contentHeight - 1 {
            viewModel.scrollViewReachedAtMax()
        }
    }
}

