//
//  UIView.swift
//  Incture
//
//  Created by Rahul Patil on 11/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//

import Foundation
import UIKit

extension UIView {
        
    func addShadow(_ cornerRadius: CGFloat = 5.0) {
        backgroundColor = UIColor.white
        layer.cornerRadius = cornerRadius
        
        layer.masksToBounds = true
        
        layer.shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: cornerRadius).cgPath
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale

        layer.shadowColor = UIColor.lightGray.cgColor
        layer.shadowOffset = CGSize.zero
        layer.shadowRadius = cornerRadius/2
        layer.shadowOpacity = 0.8
        
        layer.masksToBounds = false
    }
    
    func clipCorners(_ cornerRadius: CGFloat = 5.0) {
        layer.cornerRadius = cornerRadius
        clipsToBounds = true
    }
}

